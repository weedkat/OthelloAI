from GUI.menu_gui import run_menu

if __name__ == "__main__":
    run_menu()
